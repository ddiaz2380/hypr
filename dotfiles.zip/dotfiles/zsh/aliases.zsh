#!/bin/sh

# Use neovim for vim if present.
[ -x "$(command -v nvim)" ] && alias vim="nvim" vimdiff="nvim -d"

# Verbosity and settings that you pretty much just always are going to want.
alias \
    actualizar="sudo reflector --verbose --latest 5 --protocol http --protocol https --sort rate --save /etc/pacman.d/mirrorlist ; sudo pacman -Syu ; yay -Syu" \
	cp="cp -iv" \
	mv="mv -iv" \
	rm="rm -vI" \
	rmf="rm -rf -vI" \
	mkd="mkdir -pv" \
	ffmpeg="ffmpeg -hide_banner" \
	cpu="ps axch -o cmd:15,%cpu --sort=-%cpu | head" \
	b="btop" \
	c='clear' \
  cat='bat' \
  consphp='function _consphp() { curl "cht.sh/php+$*"; }; _consphp' \
  consjavascript='function _consjavascript() { curl "cht.sh/javascript+$*"; }; _consjavascript' \
  conssvelte='function _conssvelte() { curl "cht.sh/svelte+$*"; }; _conssvelte' \
  consvue='function _consvue() { curl "cht.sh/vue+$*"; }; _consvue' \
  conspy='function _conspy() { curl "cht.sh/python+$*"; }; _conspy' \
  consdjango='function _consdjango() { curl "cht.sh/django+$*"; }; _consdjango' \
  mecanografia='ttyper' \
  neo='neofetch' \
  rr='ranger' \
  mail='neomutt' \
  sail='bash vendor/bin/sail' \
	uni="unimatrix" \
	ping='ping -c 5' \
	ports='netstat -tulanp' \
	mapa="telnet mapscii.me" \
	mapa-lista="cat iplist.txt | iponmap" \
	traductor="gawk -f (curl -Ls --compressed https://git.io/translate | psub) -- -shell" \
	cambioippublica="sudo ifconfig eno1 192.168.100.200 netmask 255.255.255.0" \
	cambioipprivada="sudo ifconfig eno1 192.168.100.108 netmask 255.255.255.0" \
	setrouter="sudo route add default gw 192.168.100.1 eno1" \
	yt="pipe-viewer" \
	yta-aac="youtube-dl --extract-audio --audio-format aac " \
	yta-best="youtube-dl --extract-audio --audio-format best " \
	yta-flac="youtube-dl --extract-audio --audio-format flac " \
	yta-m4a="youtube-dl --extract-audio --audio-format m4a " \
	yta-mp3="youtube-dl --extract-audio --audio-format mp3 " \
	yta-opus="youtube-dl --extract-audio --audio-format opus " \
	yta-vorbis="youtube-dl --extract-audio --audio-format vorbis " \
	yta-wav="youtube-dl --extract-audio --audio-format wav " \
	ytv-best="youtube-dl -f bestvideo+bestaudio " \
	speed="curl -s https://raw.githubusercontent.com/sivel/speedtest-cli/master/speedtest.py | python -" \
	speedtest="speedtest-cli" \
	ipp="curl --max-time 10 -w '\n' http://ident.me" \
	ipl="ip a" \
	clima="curl wttr.in/Salta" \
  tm="tmux attach || tmux new -s"
  tmd="tmux detach"
  tmk="tmux kill-server"
	ve="virtualenv venv" \
	vea="source ve/bin/activate" \
	ved="deactivate" \
	pipr="pip install -r requirements.txt" \
	set mpv "mpv --no-border --force-window=no"

# Colorize commands when possible.
#ls="ls -hN --color=auto --group-directories-first" \
alias \
	ls='exa --color=auto' \
	lt='exa --tree --level=2' \
	ll='exa -lah' \
	l='exa -lbF --git' \
	la='exa -a' \
	lx='exa -lbhHigUmuSa@ --time-style=long-iso --git --color-scale' \
	grep="grep --color=auto" \
	diff="diff --color=auto" \
	ccat="highlight --out-format=ansi"

# Apache y php
alias \
    php74='sudo ln -sfn /usr/bin/php74 /usr/bin/php && echo "PHP 7.4 activado" && sudo ln -sfn /etc/httpd/conf/extra/php74.conf /etc/httpd/conf/extra/php.conf && echo "Apache configurado para PHP 7.4" && sudo systemctl restart httpd && alias composer="php74 /usr/local/bin/composer"' \
    php80='sudo ln -sfn /usr/bin/php80 /usr/bin/php && echo "PHP 8.0 activado" && sudo ln -sfn /etc/httpd/conf/extra/php80.conf /etc/httpd/conf/extra/php.conf && echo "Apache configurado para PHP 8.0" && sudo systemctl restart httpd && alias composer="php80 /usr/local/bin/composer"' \
    php81='sudo ln -sfn /usr/bin/php81 /usr/bin/php && echo "PHP 8.1 activado" && sudo ln -sfn /etc/httpd/conf/extra/php81.conf /etc/httpd/conf/extra/php.conf && echo "Apache configurado para PHP 8.1" && sudo systemctl restart httpd && alias composer="php81 /usr/local/bin/composer"' \
    php82='sudo ln -sfn /usr/bin/php82 /usr/bin/php && echo "PHP 8.2 activado" && sudo ln -sfn /etc/httpd/conf/extra/php82.conf /etc/httpd/conf/extra/php.conf && echo "Apache configurado para PHP 8.2" && sudo systemctl restart httpd && alias composer="php82 /usr/local/bin/composer"'

#Git
alias \
  gc='git clone' \
  gcl='git clone --depth 1' \
	gi='git init' \
	ga='git add' \
	gc='git commit -m' \
	gp='git push origin master'

alias \
	ka="killall" \
	g="git" \
	f="$FILE" \
	e="$EDITOR" \
	v="$EDITOR" \
	sv="sudo nvim" \
	..="cd .." \
	...="cd ../.." \
	....="cd ../../.." \
	.....="cd ../../../.." \
	......='cd ../../../../..' \
	xcp="xclip -selection clipboard"

alias \
	weath="less -S ${XDG_DATA_HOME:-$HOME/.local/share}/weatherreport" \
	dc="discord &>/dev/null & disown" \
	tg="telegram-desktop &>/dev/null & disown" \
  #wp="whatsapp-nativefier &>/dev/null & disown"

alias \
	t="kitty &>/dev/null & disown" \
	fix='echo -e "\033c"' \
	gencpio="LC_ALL=c sort | cpio --quiet -R 0:0 -o -H newc" \
	res="sudo kexec -l /boot/vmlinuz-linux --initrd=/boot/initramfs-linux.img --reuse-cmdline && sudo systemctl kexec"

# Bare git dot config
alias \
	dots=/usr/bin/git\ --git-dir=$HOME/.cfg/\ --work-tree=$HOME \
    	dpp='dots push private priv' \
    	dmp='dots push origin master' \
    	dcp='sudo chattr -i ~/.gitconfig; sudo chattr -i ~/.config/ssh; dots checkout priv' \
    	dcm='sudo chattr +i ~/.gitconfig; sudo chattr +i ~/.config/ssh; dots checkout master' \
	    glfsforcerefs="git push origin --force 'refs/heads/*'" \
    	gpl3license="wget https://www.gnu.org/licenses/gpl-3.0.md -o LICENSE.md" \
    	zcheat="zathura $ZDOTDIR/zshcheat.pdf"

#alias lf="/usr/bin/lfrun"
