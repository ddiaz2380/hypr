#/bin/bash
#  ___           _        _ _  
# |_ _|_ __  ___| |_ __ _| | | 
#  | || '_ \/ __| __/ _` | | | 
#  | || | | \__ \ || (_| | | | 
# |___|_| |_|___/\__\__,_|_|_| 
#                              
# by Stephan Raabe (2023) 
# ----------------------------------------------------- 
# Install Script for required packages
# ------------------------------------------------------

# ------------------------------------------------------
# Load Library
# ------------------------------------------------------
source $(dirname "$0")/scripts/library.sh
clear
echo "  ___           _        _ _  "
echo " |_ _|_ __  ___| |_ __ _| | | "
echo "  | ||  _ \/ __| __/ _  | | | "
echo "  | || | | \__ \ || (_| | | | "
echo " |___|_| |_|___/\__\__,_|_|_| "
echo "                              "
echo "by Stephan Raabe (2023)"
echo "-------------------------------------"
echo ""

# ------------------------------------------------------
# Check if yay is installed
# ------------------------------------------------------
if sudo pacman -Qs yay > /dev/null ; then
    echo "yay is installed. You can proceed with the installation"
else
    echo "yay is not installed. Will be installed now!"
    _installPackagesPacman "base-devel"
    git clone https://aur.archlinux.org/yay-git.git ~/yay-git
    cd ~/yay-git
    makepkg -si
    cd ~/dotfiles/
    clear
    echo "yay has been installed successfully."
    echo ""
    echo "  ___           _        _ _  "
    echo " |_ _|_ __  ___| |_ __ _| | | "
    echo "  | ||  _ \/ __| __/ _  | | | "
    echo "  | || | | \__ \ || (_| | | | "
    echo " |___|_| |_|___/\__\__,_|_|_| "
    echo "                              "
    echo "by Stephan Raabe (2023)"
    echo "-------------------------------------"
    echo ""
fi

# ------------------------------------------------------
# Confirm Start
# ------------------------------------------------------

while true; do
    read -p "DO YOU WANT TO START THE INSTALLATION NOW? (Yy/Nn): " yn
    case $yn in
        [Yy]* )
            echo "Installation started."
        break;;
        [Nn]* ) 
            exit;
        break;;
        * ) echo "Please answer yes or no.";;
    esac
done

# ------------------------------------------------------
# Install required packages
# ------------------------------------------------------
echo ""
echo "-> Install main packages"


packagesPacman=(
    "pacman-contrib"
    "zsh"
    "wget"
    "git"
    "zip"
    "unzip"
    "p7zip"
    "kitty"
    "rofi"
    "starship"
    "neovim"
    "qutebrowser"
    "neofetch"
    "mpv"
    "freerdp" 
    "xfce4-power-manager" 
    "ttf-font-awesome" 
    "ttf-fira-sans" 
    "ttf-fira-code" 
    "ttf-firacode-nerd" 
    "figlet" 
    "eza"
    "pavucontrol" 
    "tumbler"
    "xautolock"
    "blueman"
    "papirus-icon-theme"
    "polkit-gnome"
    "hyprland"
    "waybar"
    "mako"
    "grim"
    "slurp"
    "swayidle"
    "swappy"
    "cliphist"
    "brightnessctl"
);

packagesYay=(
    "pfetch"
    "libva"
    "libva-mesa-driver"
    "libva-utils"
    "libva-vdpau-driver-wayland"
    "sddm-git"
    "sddm-catppuccin-git"
    "lazygit"
    "bibata-cursor-theme"
    "swww" 
    "swaylock-effects" 
    "wlogout"
    "wlr-randr"
    "wl-clipboard"
    "wf-recorder"
    "openvpn"
    "networkmanager-openvpn"
    "nm-connection-editor"
    "ranger-git"
    "flameshot-git"
    "docker"
    "docker-compose"
    "pigz"
    "lazydocker"
    "cava"
    "python-setuptools"
    "python-pip"
    "python-psutil"
    "python-rich"
    "python-click"
    "python-gobject"
    "xdg-desktop-portal"
    "xdg-desktop-portal-wlr"
    "xdg-desktop-portal-hyprland"    
);  

# ------------------------------------------------------
# Install required packages
# ------------------------------------------------------
_installPackagesPacman "${packagesPacman[@]}";
_installPackagesYay "${packagesYay[@]}";

# ------------------------------------------------------
# Install pywal
# ------------------------------------------------------
if [ -f /usr/bin/wal ]; then
    echo "pywal already installed."
else
    yay --noconfirm -S pywal
fi

clear

# ------------------------------------------------------
# Install .zsh
# ------------------------------------------------------
echo ""
echo "-> Install .zsh"

_installSymLink .zshenv ~/.zshenv ~/dotfiles/.zshenv ~/.zshenv
_installSymLink .zprofile ~/.zprofile ~/dotfiles/.zprofile ~/.zprofile
_installSymLink .profile ~/.profile ~/dotfiles/.profile ~/.profile
_installSymLink .xsync ~/.xsync ~/dotfiles/.xsync ~/.xsync

# ------------------------------------------------------
# Install sddm display manager
# ------------------------------------------------------
echo ""
echo "-> Install sddm display manager"
while true; do
    read -p "Do you want to install the custom login prompt? (Yy/Nn): " yn
    case $yn in
        [Yy]* )
            # Set up SDDM
            echo -e "${NOTE} Setting up the login screen."
            sddm_conf_dir=/etc/sddm.conf.d
            if [ ! -d "$sddm_conf_dir" ]; then
                printf "$CAT - $sddm_conf_dir not found, creating...\n"
                sudo mkdir "$sddm_conf_dir" 2>&1 | tee -a $LOG
            fi
            echo -e "[Theme]\nCurrent=catppuccin" | sudo tee -a "$sddm_conf_dir/10-theme.conf" 2>&1 | tee -a $LOG

            wayland_sessions_dir=/usr/share/wayland-sessions
            if [ ! -d "$wayland_sessions_dir" ]; then
                printf "$CAT - $wayland_sessions_dir not found, creating...\n"
                sudo mkdir "$wayland_sessions_dir" 2>&1 | tee -a $LOG
            fi
            sudo cp misc/hyprland.desktop "$wayland_sessions_dir/" 2>&1 | tee -a $LOG

            sudo systemctl enable sddm.service
            break;;
        [Nn]* ) 
            echo "sddm installation skipped."
            break;;
        * ) echo "Please answer yes or no.";;
    esac
done

# ------------------------------------------------------
# Install wallpapers
# ------------------------------------------------------
echo ""
echo "-> Install wallapers"
while true; do
    read -p "Do you want to clone the wallpapers? If not, the script will install 3 default wallpapers to ~/wallpaper/ (Yy/Nn): " yn
    case $yn in
        [Yy]* )
            if [ -d ~/wallpaper/ ]; then
                echo "wallpaper folder already exists."
            else
                git clone https://gitlab.com/stephan-raabe/wallpaper.git ~/wallpaper
                echo "wallpaper installed."
            fi
            echo "Wallpaper installed."
        break;;
        [Nn]* ) 
            if [ -d ~/wallpaper/ ]; then
                echo "wallpaper folder already exists."
            else
                mkdir ~/wallpaper
            fi
            cp ~/dotfiles/wallpapers/* ~/wallpaper
            echo "Default wallpapers installed."
        break;;
        * ) echo "Please answer yes or no.";;
    esac
done

# ------------------------------------------------------
# Init pywal
# ------------------------------------------------------
echo ""
echo "-> Init pywal"
wal -i ~/dotfiles/wallpapers/default.jpg
echo "pywal initiated."

# ------------------------------------------------------
# Copy default wallpaper to .cache
# ------------------------------------------------------
echo ""
echo "-> Copy default wallpaper to .cache"
cp ~/dotfiles/wallpapers/default.jpg ~/.cache/current_wallpaper.jpg
echo "default wallpaper copied."

# ------------------------------------------------------
# DONE
# ------------------------------------------------------
clear
echo "DONE!" 
echo "NEXT: Please continue with 2-install-hyprland.sh and/or 2-install-qtile.sh"
