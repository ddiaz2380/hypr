#!/bin/bash
theme_name="Default"
