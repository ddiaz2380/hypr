#!/bin/bash
iso_dir="/home/daniel/iso/"
iso_icon=""
qemu_icon="/usr/share/icons/hicolor/128x128/apps/qemu.png"
option=$(echo -e "Crear máquina virtual\nListar máquinas virtuales" | rofi -dmenu -i -p "Opción:")
if [ "$option" = "Crear máquina virtual" ]; then
    distro=$(echo "" | rofi -dmenu -i -p "Distribución:")
    cpu=$(echo "" | rofi -dmenu -i -p "Número de CPUs:")
    mem=$(echo "" | rofi -dmenu -i -p "Memoria (en MB):")
    iso_file=$(ls "$iso_dir" | rofi -dmenu -i -p "Selecciona un archivo ISO:" -mesg "$iso_icon")
    iso="${iso_dir}${iso_file}"
    size=$(echo "" | rofi -dmenu -i -p "Tamaño del disco (en GB):")
    #os=$(echo "" | rofi -dmenu -i -p "Tipo de sistema operativo (os-variant):")
    boot_option=$(echo -e "BIOS\nUEFI" | rofi -dmenu -i -p "Selecciona una opción de booteo:")
    if [ "$boot_option" = "BIOS" ]; then
        bios_option="--boot bios"
    elif [ "$boot_option" = "UEFI" ]; then
        bios_option="--boot uefi"
    fi
    create_option=$(echo -e "Sí\nNo" | rofi -dmenu -i -p "¿Está seguro de crear la máquina virtual '$distro'?")
    if [ "$create_option" = "Sí" ]; then
        sudo virt-install --name="$distro" --vcpus="$cpu" --memory="$mem" --cdrom="$iso" --disk size="$size" --os-variant="$os" $bios_option
        notify-send -u normal -i "$qemu_icon" "Máquina virtual creada" "Se ha creado la máquina virtual '$distro' con booteo $boot_option"
        confirm=$(echo -e "Sí\nNo" | rofi -dmenu -i -p "Se ha creado la máquina virtual '$distro'. ¿Desea cerrar el script?")
        if [ "$confirm" = "Sí" ]; then
            exit 0
        else
            exec $0
        fi
    else
        confirm=$(echo -e "Sí\nNo" | rofi -dmenu -i -p "No se ha creado la máquina virtual. ¿Desea cerrar el script?")
        if [ "$confirm" = "Sí" ]; then
            exit 0
        else
            exec $0
        fi
    fi
elif [ "$option" = "Listar máquinas virtuales" ]; then
    vm_list=$(sudo virsh list --all | awk '{print $2}' | grep -v "^$")
    if [ -z "$vm_list" ]; then
        rofi -e "No hay máquinas virtuales creadas"
        confirm=$(echo -e "Sí\nNo" | rofi -dmenu -i -p "¿Desea cerrar el script?")
        if [ "$confirm" = "Sí" ]; then
            exit 0
        else
            exec $0
        fi
    else
        vm=$(echo "$vm_list" | rofi -dmenu -i -p "Selecciona una máquina virtual:")
        vm_option=$(echo -e "Modificar cantidad de cores y memoria\nIniciar\nDetener\nEliminar\nEliminar máquina virtual con UEFI" | rofi -dmenu -i -p "Selecciona una opción para la máquina virtual '$vm':")
        if [ "$vm_option" = "Modificar cantidad de cores y memoria" ]; then
            cpu=$(echo "" | rofi -dmenu -i -p "Nuevo número de CPUs:")
            mem=$(echo "" | rofi -dmenu -i -p "Nueva memoria (en MB):")
            sudo virsh setvcpus "$vm" "$cpu"
            sudo virsh setmem "$vm" "$mem"M
            notify-send -u normal -i "$qemu_icon" "Máquina virtual modificada" "Se ha modificado la máquina virtual '$vm' con $cpu núcleos y $mem MB de memoria"
            exec $0
        elif [ "$vm_option" = "Iniciar" ]; then
            sudo virsh start "$vm"
            notify-send -u normal -i "$qemu_icon" "Máquina virtual iniciada" "Se ha iniciado la máquina virtual '$vm'"
            exec $0
        elif [ "$vm_option" = "Detener" ]; then
            sudo virsh destroy "$vm"
            notify-send -u normal -i "$qemu_icon" "Máquina virtual detenida" "Se ha detenido la máquina virtual '$vm'"
            exec $0
        elif [ "$vm_option" = "Eliminar" ]; then
            delete_option=$(echo -e "Sí\nNo" | rofi -dmenu -i -p "¿Está seguro de eliminar la máquina virtual '$vm'?")
            if [ "$delete_option" = "Sí" ]; then
                sudo virsh destroy "$vm"
                sudo virsh undefine "$vm"
                notify-send -u normal -i "$qemu_icon" "Máquina virtual eliminada" "Se ha eliminado la máquina virtual '$vm'"
                confirm=$(echo -e "Sí\nNo" | rofi -dmenu -i -p "Se ha eliminado la máquina virtual '$vm'. ¿Desea cerrar el script?")
                if [ "$confirm" = "Sí" ]; then
                    exit 0
                else
                    exec $0
                fi
            else
                confirm=$(echo -e "Sí\nNo" | rofi -dmenu -i -p "No se ha eliminado la máquina virtual '$vm'. ¿Desea cerrar el script?")
                if [ "$confirm" = "Sí" ]; then
                    exit 0
                else
                    exec $0
                fi
            fi
        elif [ "$vm_option" = "Eliminar máquina virtual con UEFI" ]; then
            delete_option=$(echo -e "Sí\nNo" | rofi -dmenu -i -p "¿Está seguro de eliminar la máquina virtual '$vm' con UEFI?")
            if [ "$delete_option" = "Sí" ]; then
                nvram_dir="/var/lib/libvirt/qemu/nvram/"
                nvram_files=$(sudo ls "$nvram_dir")
                if [ -n "$nvram_files" ]; then
                    nvram_file=$(echo "$nvram_files" | rofi -dmenu -i -p "Selecciona un archivo NVRAM a eliminar:")
                    sudo rm -f "${nvram_dir}${nvram_file}"
                fi
                images_dir="/var/lib/libvirt/images/"
                images_files=$(sudo ls "$images_dir")
                if [ -n "$images_files" ]; then
                    images_file=$(echo "$images_files" | rofi -dmenu -i -p "Selecciona una Imagen de disco a eliminar:")
                    sudo rm -f "${images_dir}${images_file}"
                fi
                sudo virsh destroy "$vm"
                sudo virsh undefine "$vm"
                notify-send -u normal -i "$qemu_icon" "Máquina virtual eliminada" "Se ha eliminado la máquina virtual '$vm' con UEFI"
                confirm=$(echo -e "Sí\nNo" | rofi -dmenu -i -p "Se ha eliminado la máquina virtual '$vm' con UEFI. ¿Desea cerrar el script?")
                if [ "$confirm" = "Sí" ]; then
                    exit 0
                else
                    exec $0
                fi
            else
                confirm=$(echo -e "Sí\nNo" | rofi -dmenu -i -p "No se ha eliminado la máquina virtual '$vm' con UEFI. ¿Desea cerrar el script?")
                if [ "$confirm" = "Sí" ]; then
                    exit 0
                else
                    exec $0
                fi
            fi
        fi
    fi
fi
