#!/bin/bash

# Obtén la lista de unidades montadas
unidad_montada=$(mount | awk '$1 ~ /\/dev/ {print $1}' | rofi -dmenu -p "Selecciona una unidad para desmontar:")

# Verifica si se seleccionó una unidad montada
if [ -n "$unidad_montada" ]; then
    # Intenta desmontar la unidad
    sudo umount "$unidad_montada"
    
    # Verifica si el desmontaje fue exitoso
    if [ $? -eq 0 ]; then
        echo "La unidad se ha desmontado correctamente."
    else
        echo "Error al intentar desmontar la unidad."
    fi
else
    echo "No se seleccionó ninguna unidad para desmontar."
fi
