#!/bin/bash

# Obtener la lista de atajos de teclado
KEYS=$(python -c "
from libqtile.config import Key
from libqtile.lazy import lazy

config = {}
exec(open('$HOME/.config/qtile/config.py').read(), config)

keys_list = []
for i in range(1, 10):
    keys_list.append(Key([], str(i), lazy.screen.togglegroup(str(i))))

for key in keys_list:
    print('{:<20} {}'.format(str(key.key), key.cmd))
")

# Mostrar los atajos de teclado en una ventana de Rofi
echo "$KEYS" | rofi -dmenu -i -p "Qtile key bindings:" -width 1000
