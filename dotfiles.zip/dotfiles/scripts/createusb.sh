#!/bin/bash

# Función para seleccionar un archivo ISO
function select_iso {
    iso_file=$(find /home/daniel/iso -type f -name "*.iso" | rofi -dmenu -i -p "Seleccione un archivo ISO:")
    if [ -z "${iso_file}" ]; then
        echo "No se seleccionó ningún archivo ISO"
        exit 1
    fi
    echo "${iso_file}"
}

# Función para seleccionar un dispositivo USB
function select_usb {
    usb_device=$(lsblk -dplnx size -o name,size | grep -Ev "boot|rpmb|loop" | rofi -dmenu -i -p "Seleccione un dispositivo USB:")
    if [ -z "${usb_device}" ]; then
        echo "No se seleccionó ningún dispositivo USB"
        exit 1
    fi
    echo "${usb_device}"
}

# Selecciona el archivo ISO
iso_file=$(select_iso)

# Selecciona el dispositivo USB
usb_device=$(select_usb)

# Verifica que el dispositivo USB esté desmontado
if mount | grep "${usb_device}" >/dev/null; then
    echo "El dispositivo USB ${usb_device} está montado. Por favor desmóntelo antes de continuar."
    exit 1
fi

# Crea la ventana rofi para mostrar el progreso
rofi_window=$(echo -e "Progreso:\n\n")
(echo "${rofi_window}" && sudo dd if=${iso_file} of=${usb_device} status=progress 2>&1) | rofi -dmenu -i -p "Creando USB booteable. Por favor, espere..." -mesg "Presione Enter para cerrar esta ventana y abrir una terminal con el progreso." -no-custom

# Abre una terminal y muestra el progreso en la salida estándar de error
kitty --title="Progreso de creación de USB booteable" -x bash -c "(echo -e 'Progreso:\n\n' && sudo dd if=${iso_file} of=${usb_device} status=progress 2>&1) && echo -e '\nPresione Enter para cerrar esta ventana.' && read" & disown
