#!/bin/bash

# Obtén la lista de unidades disponibles
unidad=$(lsblk -pno "NAME,MOUNTPOINT" | awk '$2 == "" {print $1}' | rofi -dmenu -p "Selecciona una unidad:")

# Verifica si se seleccionó una unidad
if [ -n "$unidad" ]; then
    # Pregunta por el punto de montaje deseado
    punto_montaje=$(rofi -dmenu -p "Punto de montaje para $unidad:")

    # Verifica si se ingresó un punto de montaje
    if [ -n "$punto_montaje" ]; then
        # Intenta montar la unidad
        sudo mount "$unidad" "$punto_montaje"
        if [ $? -eq 0 ]; then
            echo "La unidad se ha montado correctamente en $punto_montaje"
        else
            echo "Error al intentar montar la unidad."
        fi
    else
        echo "No se ingresó un punto de montaje."
    fi
else
    echo "No se seleccionó ninguna unidad."
fi
