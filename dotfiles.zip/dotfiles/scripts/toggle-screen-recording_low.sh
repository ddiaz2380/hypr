# $HOME/scripts/toggle-screen-recording.sh
# ------------------------------------------

#!/bin/bash 
pid=`pgrep wf-recorder`
status=$?

if [ $status != 0 ] 
then 
  wf-recorder -a -g "$(slurp)" --audio --file=$(xdg-user-dir VIDEOS)/Capturas/$(date +'recording_%Y-%m-%d-%H%M%S.webm');
else 
  pkill --signal SIGINT wf-recorder
fi;
