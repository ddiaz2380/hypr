#!/bin/sh
# Sin historial
#  rofi -show calc -modi calc -no-show-match -no-sort -no-history -lines 0
#  LC_MONETARY=es_AR.UTF-8 rofi -modi calc -show calc -calc-command -hint-result 'xdotool type --clearmodifiers "{result}"'
#  rofi -show calc -modi calc -no-show-match -no-sort -calc-command "echo -n '{result}' | xclip"
#  Con historial
   rofi -modi calc -show calc -calc-command 'xdotool type --clearmodifiers "{result}"'
  @import "~/.cache/wal/colors-rofi-pywal"
  -location 0 \
  -theme-str 'window {width: 300px; height: 500px; padding: 0;}' \
  -theme-str 'listview {border: 0px; scrollbar: 0;}' \
  -yoffset -50 \
  -kb-element-next j \
  -kb-element-prev k \
  -input "echo '' | bc -l" \
