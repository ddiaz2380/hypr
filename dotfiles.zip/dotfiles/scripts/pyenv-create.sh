#!/bin/zsh

function list_installed_python_versions {
    pyenv versions --bare
}

function choose_python_version {
    installed_versions=$(list_installed_python_versions)
    if [[ -z $installed_versions ]]; then
        echo "No se encontraron versiones de Python instaladas con pyenv."
        exit 1
    fi

    python_version=$(echo $installed_versions | tr ' ' '\n' | rofi -dmenu -p "Selecciona la versión de Python:")
    echo $python_version
}

function choose_virtualenv_folder {
    env_folder=$(zenity --file-selection --directory --title="Selecciona la carpeta para el nuevo entorno virtual")
    if [[ -z $env_folder || ! -d $env_folder ]]; then
        echo "La carpeta especificada no es válida."
        exit 1
    fi
    echo $env_folder
}

function enter_project_name {
    project_name=$(rofi -dmenu -p "Nombre del nuevo entorno virtual:")
    if [[ -z $project_name ]]; then
        echo "El nombre del proyecto no puede estar vacío."
        exit 1
    fi
    echo $project_name
}

function create_virtualenv {
    # Configurar Pyenv
    eval "$(pyenv init --path)"

    python_version=$(choose_python_version)
    env_folder=$(choose_virtualenv_folder)
    project_name=$(enter_project_name)

    # Crear el entorno virtual con venv
    python -m venv $env_folder/$project_name
    echo "Entorno virtual '$project_name' creado en $env_folder."

    # Activar el entorno virtual
    source $env_folder/$project_name/bin/activate
    echo "Entorno virtual '$project_name' activado con Python $python_version."
}

create_virtualenv
