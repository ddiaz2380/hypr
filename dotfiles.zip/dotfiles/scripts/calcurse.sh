kitty -e calcurse
