#!/bin/bash

if pgrep -x "tor" > /dev/null
then
    status="on"
    ip=$(torify curl -s ifconfig.me)
else
    status="off"
    ip="N/A"
fi

echo '{"status": "'"$status"'", "ip": "'"$ip"'"}'
```
