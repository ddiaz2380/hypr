wezterm start --always-new-process

