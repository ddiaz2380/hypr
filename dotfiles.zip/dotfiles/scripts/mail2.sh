#!/usr/bin/env sh

# reads accounts in order of mutt (i1, i2, i3, ... with mutt-wizard)
acc=$(cat $HOME/.config/mutt/muttrc | grep "i[0-9]" | grep -o "switch to [^\"]*" | awk '{print $3}')

unread_count=0
for x in $acc; do
    count="$(find "${XDG_DATA_HOME:-$HOME/.local/share}"/mail/"$x"/[Ii][Nn][Bb][Oo][Xx]/new/* -type f | wc -l 2>/dev/null)"
    unread_count=$((unread_count + count))
done 2>/dev/null

if [ "$unread_count" -gt 0 ]; then
    echo "$unread_count" | sed 's/\^.\^//g'
fi
