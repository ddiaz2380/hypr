#!/bin/bash

# Mostrar el cuadro de texto con más espacio para el nombre del archivo
output=$(echo "" | dmenu -l 1 -p "Nombre :")

# Verificar si se ha cancelado la entrada (tecla Escape)
if [ -z "$output" ]; then
	dunstify "Proceso cancelado." -u normal
	exit 0
fi

# Mostrar cuadro de diálogo de confirmación con zenity
confirmation=$(zenity --question --text="¿Desea crear el archivo $output.zip?" --width=300)

# Verificar la opción seleccionada en el cuadro de diálogo de confirmación
if [ $? -eq 0 ]; then
	# Si selecciona Sí, crear el archivo
	if zip -r "$output.zip" .; then
		# Mostrar mensaje con zenity después de crear el archivo
		zenity --info --text="Éxito: Archivo comprimido exitosamente: $output.zip"
	else
		zenity --error --text="Error: Hubo un problema al comprimir el archivo."
	fi
else
	# Si selecciona No, mostrar mensaje y salir
	dunstify "Proceso cancelado." -u normal
fi

# Salir sin mostrar mensajes adicionales
exit 0
