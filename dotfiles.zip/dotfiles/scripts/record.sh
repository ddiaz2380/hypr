#!/bin/bash

pid=$(pgrep wf-recorder)
status=$?

if [ $status != 0 ]; then
    opciones="Área seleccionada\nPantalla completa\nCancelar"
    eleccion=$(echo -e "$opciones" | rofi -dmenu -i -p "Elige el modo de grabación")

    case $eleccion in
        "Área seleccionada")
            region=$(slurp)
            ;;
        "Pantalla completa")
            region="screen"
            ;;
        *)
            exit 0
            ;;
    esac

    cuadros_por_segundo="20\n30\n40\n50\n60"
    cuadros=$(echo -e "$cuadros_por_segundo" | rofi -dmenu -p "Elige los cuadros por segundo")

    if [ -z "$cuadros" ]; then
        notify-send "Grabación cancelada" "No se seleccionó un número de cuadros por segundo"
        exit 0
    fi

    opciones_audio="Audio de la PC\nSin audio"
    eleccion_audio=$(echo -e "$opciones_audio" | rofi -dmenu -p "Grabar audio de la PC o sin audio")

    if [ -z "$eleccion_audio" ]; then
        notify-send "Grabación cancelada" "No se seleccionó una opción de audio"
        exit 0
    fi

    if [ "$eleccion_audio" == "Audio de la PC" ]; then
        opciones_microfono="Audio del micrófono\nSin micrófono"
        eleccion_microfono=$(echo -e "$opciones_microfono" | rofi -dmenu -p "Incluir audio del micrófono o no")

        if [ -z "$eleccion_microfono" ]; then
            notify-send "Grabación cancelada" "No se seleccionó una opción de micrófono"
            exit 0
        fi

        if [ "$eleccion_microfono" == "Audio del micrófono" ]; then
            entrada_audio="--audio"
        else
            entrada_audio=""
        fi
    else
        entrada_audio=""
    fi

    notify-send "Grabación iniciada" "Modo: $eleccion\nCuadros por segundo: $cuadros\nAudio: $eleccion_audio\nMicrófono: $eleccion_microfono"

    wf-recorder -g $region --fps $cuadros $entrada_audio -c h264_vaapi -d /dev/dri/renderD128 -f "$(xdg-user-dir VIDEOS)/Capturas/grabacion_$(date +%Y-%m-%d-%H%M%S).mp4"

    notify-send "Grabación completada" "Video guardado como: $(xdg-user-dir VIDEOS)/Capturas/grabacion_$(date +%Y-%m-%d-%H%M%S).mp4"
else
    pkill --signal SIGINT wf-recorder
fi
