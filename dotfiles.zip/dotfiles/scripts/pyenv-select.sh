#!/bin/bash

# Obtener las versiones de Python instaladas en Pyenv
python_versions=$(pyenv versions --bare)

# Verificar si hay versiones instaladas
if [ -z "$python_versions" ]; then
    echo "No se encontraron versiones de Python instaladas con pyenv."
    exit 1
fi

# Formatear las versiones en líneas individuales para Rofi
formatted_versions=$(echo "$python_versions" | tr ' ' '\n')

# Usar Rofi para seleccionar la versión de Python
selected_version=$(echo "$formatted_versions" | rofi -dmenu -p "Selecciona la versión de Python:")

# Verificar si se seleccionó una versión
if [ -n "$selected_version" ]; then
    pyenv global "$selected_version"
    echo "Versión de Python global establecida a: $selected_version"
else
    echo "No se seleccionó ninguna versión de Python."
fi
