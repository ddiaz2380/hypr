#!/bin/bash

# Mostrar menú Rofi para opciones de grabación
selected_option=$(echo -e "Pantalla Completa\nSeleccionar Área" | rofi -dmenu -p "Selecciona una opción")

case "$selected_option" in
  "Pantalla Completa")
    region="-a"
    ;;
  "Seleccionar Área")
    region="-g \"$(slurp)\""
    ;;
  *)
    echo "Opción no válida"
    exit 1
    ;;
esac

# Mostrar menú Rofi para tasas de fotogramas
framerate=$(echo -e "30\n40\n50\n59\n60" | rofi -dmenu -p "Selecciona la tasa de fotogramas")

# Mostrar menú Rofi para audio
audio_option=$(echo -e "Con Audio\nSin Audio" | rofi -dmenu -p "Selecciona una opción de audio")

case "$audio_option" in
  "Con Audio")
    audio="-c h264_vaapi -d /dev/dri/renderD128"
    ;;
  "Sin Audio")
    audio=""
    ;;
  *)
    echo "Opción no válida"
    exit 1
    ;;
esac

# Mostrar menú Rofi para el formato de video
video_format=$(echo -e "mp4\nmkv\navi\nmpeg\nwebm" | rofi -dmenu -p "Selecciona el formato de video")

pid=$(pgrep wf-recorder)
status=$?

if [ $status != 0 ]; then
  case "$video_format" in
    "mp4")
      video_codec="h264_vaapi"
      ;;
    "mkv")
      video_codec="h264_vaapi"
      ;;
    "avi")
      video_codec="h264_vaapi"
      ;;
    "mpeg")
      video_codec="h264_vaapi"
      ;;
    "webm")
      video_codec="h264_vaapi"
      ;;
    *)
      echo "Formato de video no válido"
      exit 1
      ;;
  esac

  wf-recorder $region -f $framerate $audio -f "$(xdg-user-dir VIDEOS)/Capturas/$(date +'recording_%Y-%m-%d-%H%M%S').$video_format" -c $video_codec -acodec vorbis
else
  pkill --signal SIGINT wf-recorder
fi
