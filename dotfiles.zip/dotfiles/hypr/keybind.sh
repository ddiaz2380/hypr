config_file=~/.config/hypr/conf/keybindings.conf
keybinds=$(grep -oP '(?<=bind = ).*' $config_file)
keybinds=$(echo "$keybinds" | sed 's/,\([^,]*\)$/ = \1/' | sed 's/, exec//g' | sed 's/^,//g')
rofi -dmenu -config ~/dotfiles/rofi/config-wallpaper.rasi "Keybinds" <<< "$keybinds"
