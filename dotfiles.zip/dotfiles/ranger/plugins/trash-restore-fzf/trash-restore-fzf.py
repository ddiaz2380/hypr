import subprocess32 as subprocess
from ranger.api.commands import Command

class trash_restore_fzf(Command):
    """
    :trash-restore-fzf:
        Restore the selected file from trash using fzf

    """
    def execute(self):
        selected_file = subprocess.run(["trash-restore-fzf"], stdout=subprocess.PIPE, shell=True).stdout.decode().strip()
        self.fm.notify(selected_file)
